import Submissions.hailey_collet_1252270103.Cycle61.Physical.InitialMass.SecondEncoding
import Submissions.hailey_collet_1252270103.Cycle61.Physical.InitialMass.SecondPhysicalWindows
import Submissions.openai_baseline.OAI.NumberTheory.DirichletL.Moments.OriginalCommonHarmonic

set_option autoImplicit false
set_option maxHeartbeats 800000
namespace OAI.SevenEighths.Cycle61InitialMass
noncomputable section
open scoped Classical BigOperators
open HeckeFamily CanonicalQuadraticSieve CompletedGauss
open CenteredMomentCommonRadialData CenteredMomentSourceMass
open CenteredMomentOriginalCommonHarmonic CenteredMomentActiveSource
open CenteredMomentFirstSectors CenteredMomentSourceRow CenteredMomentCanonicalFirst
open CenteredMomentSecondRetainedAggregate
open CenteredMomentSecondExceptionalFamily CenteredMomentSecondActiveCount
local notation "O" => HeckeFamily.O
local instance secondActualSourcesDecidableSum {ι : Type*} : DecidableEq (ι⊕Fin 2) := Classical.decEq _

variable {α : Type*} [Fintype α] [DecidableEq α]

abbrev ActualSecondPair {ι : Type*} [Fintype ι] (s : Input ι) (R seed : Ideal O) :=
  ↥(commonLabels
    (supportedColumns (activeSource (finiteColumns (Fintype.piFinset s.pools)) (coefficient s R seed)))
    (supportedColumns (activeSource (finiteColumns (Fintype.piFinset s.pools)) (coefficient s R seed))))

/-- A second input is constructed from actual active common labels. Its
character family is supplied by the proved finite-character construction. -/
def actualSecondInputDatum (slots : Finset α) (s : Input slots) (R seed : Ideal O)
    (hseed : Squarefree seed) (hz₁ : s.W₁ 0=0) (hz₂ : s.W₂ 0=0)
    (p : ActualSecondPair s R seed) (U : Finset (CommonIndex p.val.1 p.val.2))
    (radius : ℝ) (rows : Finset O) (hrows : ∀z∈rows,z≠0)
    (K : ℝ) (hK : 0<K) (dyad : Fin 4→ℤ) : SecondInputDatum α :=
  let hp := commonLabels_supported
    (activeSource (finiteColumns (Fintype.piFinset s.pools)) (coefficient s R seed))
      _ _ p.property
  let hg := actual_common_gates s R seed hseed hz₁ hz₂ _ _ p.property
  let hf := exists_row_budgeted_second_family s.η _ _ hp.1 hp.2 hg.2.2.1 U
  {slots:=slots,input:=s,R:=R,seed:=seed,C:=p.val.1,D:=p.val.2,
    hC:=hp.1,hD:=hp.2,sameSupport:=hg.2.2.1,inactive:=U,
    radius:=radius,rows:=rows,rows_ne:=hrows,K:=K,K_pos:=hK,dyad:=dyad,
    τ:=Classical.choose hf,family:=(Classical.choose_spec hf).1,
    rowBudget:=(Classical.choose_spec hf).2}

/-- The first projector divides both actual second common ideals; these
hypotheses no longer have to be supplied at the encoding boundary. -/
theorem actual_second_input_seed (slots : Finset α) (s : Input slots) (R seed : Ideal O)
    (hseed : Squarefree seed) (hz₁ : s.W₁ 0=0) (hz₂ : s.W₂ 0=0)
    (p : ActualSecondPair s R seed) (U : Finset (CommonIndex p.val.1 p.val.2))
    (radius : ℝ) (rows : Finset O) (hrows : ∀z∈rows,z≠0)
    (K : ℝ) (hK : 0<K) (dyad : Fin 4→ℤ) :
    let d := actualSecondInputDatum slots s R seed hseed hz₁ hz₂ p U radius rows hrows K hK dyad
    d.seed∣d.C ∧ d.seed∣d.D := by
  have h := actual_common_gates s R seed hseed hz₁ hz₂ _ _ p.property
  exact ⟨h.2.2.2.1,h.2.2.2.2.1⟩

theorem actual_second_input_common_norm (slots : Finset α) (s : Input slots) (R seed : Ideal O)
    (hseed : Squarefree seed) (hz₁ : s.W₁ 0=0) (hz₂ : s.W₂ 0=0)
    (p : ActualSecondPair s R seed) (U : Finset (CommonIndex p.val.1 p.val.2))
    (radius : ℝ) (rows : Finset O) (hrows : ∀z∈rows,z≠0)
    (K : ℝ) (hK : 0<K) (dyad : Fin 4→ℤ) :
    let d := actualSecondInputDatum slots s R seed hseed hz₁ hz₂ p U radius rows hrows K hK dyad
    (d.C.absNorm:ℝ)≤sourceRadius s ∧ (d.D.absNorm:ℝ)≤sourceRadius s := by
  exact (actual_common_gates s R seed hseed hz₁ hz₂ _ _ p.property).2.2.2.2.2

end
end OAI.SevenEighths.Cycle61InitialMass
#print axioms OAI.SevenEighths.Cycle61InitialMass.actual_second_input_seed
#print axioms OAI.SevenEighths.Cycle61InitialMass.actual_second_input_common_norm
