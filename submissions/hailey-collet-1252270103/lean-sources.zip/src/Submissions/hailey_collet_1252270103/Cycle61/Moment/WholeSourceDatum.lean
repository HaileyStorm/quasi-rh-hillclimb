import Submissions.hailey_collet_1252270103.Cycle61.Moment.WholeSourceConductor

set_option autoImplicit false
namespace OAI.SevenEighths.Cycle61Moment
noncomputable section
open scoped Classical
open HeckeFamily CenteredMomentEnergyState CenteredMomentNaturalRowSource
open CenteredMomentEligibleEnergy CenteredMomentDivisorAllocation CenteredMomentDivisorRaw
open ConcreteTraceCRT LowBranch CenteredMomentRetainedProfile
local notation "O" => HeckeFamily.O

variable (M : Ideal O) [NeZero M]
local instance : Finite (O ⧸ M) := Ring.HasFiniteQuotients.finiteQuotient (NeZero.ne M)
variable (H : Subgroup (O ⧸ M)ˣ) (hH : RayOrthogonality.globalUnits M ≤ H)

def wholeHighDatum {ι : Type} [Fintype ι] [DecidableEq ι]
    (P : HighSourceParameters) (η₀ : Character) (Z : ℝ)
    (st : NaturalState Z P.Bmask P.bΦ)
    (hQM : st.fixedModulus ≤ M) (hQη : st.fixedModulus ≤ η₀.modulus)
    (z : O) (hz : st.radial.keep z) (s : Data ι) (second : Bool)
    (L : Ideal O) (alloc : Allocation L (Finset.univ : Finset (ι ⊕ Fin 2)))
    (w σ v : ι → ℝ) (θ : ι → RayQuotient.Characters M H) (ap bp : ℝ) :
    HighSourceDatum M H P η₀ Z (WholeSourceIndex M H) where
  state := st
  hQM := hQM
  hQη := hQη
  z := z
  hz := hz
  natural := naturalRow st.character z (st.row_ne_zero z hz)
  character := wholeSourceFamily M H hH η₀
    (excluded (naturalRow st.character z (st.row_ne_zero z hz)).character st.puncture)
  hcharacter := whole_source_family_nonprincipal M H hH st η₀ hQM hQη z hz _
  member := Sum.inl ()
  Slot := ι
  source := s
  second := second
  projector := L
  allocation := alloc
  w := w
  σ := σ
  v := v
  θ := θ
  t := s.t
  W := ![s.W₁,s.W₂]
  X := Cycle61.Physical.postPlainScale L alloc
    (Cycle61.Physical.sourcePlainScales s.toSource second)
  r := fun j => Real.logb Z (clippedScale (Cycle61.Physical.postPlainScale L alloc
    (Cycle61.Physical.sourcePlainScales s.toSource second) j))/P.d
  A := fun _ => ap
  B := fun _ => bp


theorem whole_high_datum_low {ι : Type} [Fintype ι] [DecidableEq ι]
    (P : HighSourceParameters) (η₀ : Character) (Z : ℝ)
    (st : NaturalState Z P.Bmask P.bΦ)
    (hQM : st.fixedModulus ≤ M) (hQη : st.fixedModulus ≤ η₀.modulus)
    (z : O) (hz : st.radial.keep z) (s : Data ι) (second : Bool)
    (L : Ideal O) (alloc : Allocation L (Finset.univ : Finset (ι ⊕ Fin 2)))
    (w σ v : ι → ℝ) (θ : ι → RayQuotient.Characters M H) (ap bp a : ℝ) (i : ℕ)
    (hs : st.radial.profile (‖eisEmbedding z‖^2/st.radial.scale) ≠ 0)
    (hupper : let D := wholeHighDatum M H hH P η₀ Z st hQM hQη z hz s second L alloc w σ v θ ap bp
      HeckeDetectorZeros.zeroMaximum D.character D.hcharacter (3*(i+1 : ℕ)*Z^P.τ) < a+2*P.e) :
    ActualLow M H hH st η₀ hQM hQη a P.e (3*(i+1 : ℕ)*Z^P.τ) z := by
  exact whole_source_upper_actual_low M H hH st η₀ hQM hQη z hz a P.e _ hs hupper

#print axioms wholeHighDatum
#print axioms whole_high_datum_low
end
end OAI.SevenEighths.Cycle61Moment
