# Exact used Lean sources

Hailey Collet — c = 1252270103/10000000000.
Frozen source: https://github.com/HaileyStorm/QuasiRiemannTracker/tree/ac76d5ef6008d976a7b8f3c1d921af2317e79ce9
Entry: Candidate.bound, src/Candidate/Main.lean.

The src directory contains the entry and complete used project/baseline source closure (6471 modules). Toolchain pins, source provenance and inherited notices accompany the sources. No compiled objects are included. Use verifier/standard at the frozen repository revision for official reproduction with Lean 4.34.1 and its pinned packages.

See the containing hillclimb submission's README.md and verification/ for successful local checks and their exact scopes. The complete closure has been compiled in resumed development, and Candidate.bound's separate axiom audit exited zero with propext, Classical.choice and Quot.sound only. A complete fresh final replay and endpoint acceptance by Comparator plus Lean/NanoDa/con-ron remain outstanding. Tracker PR: https://github.com/GTimG/QuasiRiemannTracker/pull/69.

New code: Apache-2.0. Inherited licenses/notices are retained in the sources and provenance.json. QRH-Catalogue: https://github.com/HaileyStorm/QRH-Catalogue. Author: https://x.com/HaileyStormC.
